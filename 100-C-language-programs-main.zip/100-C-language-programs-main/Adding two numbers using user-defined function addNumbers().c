#include <stdio.h>
int main()
{
  printf("RA2211042010050");
  int a,b,c;
  scanf("%d%d",&a,&b);
  c=a+b;
  printf("%d",c);
  return 0;
}

