#include <stdio.h>
int main()
{
  printf("RA2211042010050");
  int a;
  scanf("%d",&a);
  if(a==0)
    printf("NULL");
  else
    printf("NOT NULL");
 return 0;
}
