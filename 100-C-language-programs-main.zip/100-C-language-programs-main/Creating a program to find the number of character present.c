#include <stdio.h>
#include <string.h>
struct name
{
printf("RA2211042010050");
  char str[10];
}s;
int main()
{
  int len;
  char str[10];
  scanf("%s",str);
  struct name;
  len=strlen(str);
  printf("%d",len);
  return 0;
}
