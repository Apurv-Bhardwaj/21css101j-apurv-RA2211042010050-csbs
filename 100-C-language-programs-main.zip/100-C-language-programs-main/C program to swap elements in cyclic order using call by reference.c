#include <stdio.h>
int main()
{
  printf("RA2211042010050");
  int a,b,c;
  scanf("%d%d%d",&a,&b,&c);
  printf("%d",c);
  printf("\n%d",a);
  printf("\n%d",b);
 return 0;
}
