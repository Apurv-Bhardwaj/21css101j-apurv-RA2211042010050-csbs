#include <stdio.h>
int main()
{
 printf("RA2211042010050");
  int a,b,c;
  scanf("%d%d%d",&a,&b,&c);
  printf("The gain percentage is=%0.2f",((c-a-b)*1.0/(a+b))*100);
  return 0;
}
