#include <stdio.h>
int main()
{
int a;
scanf("%d",&a); 
if(a>=18 && a<=60)
printf("satisfying");
else
printf("not satisfying");
  return 0;
}
